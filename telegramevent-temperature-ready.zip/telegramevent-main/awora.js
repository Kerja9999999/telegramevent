const activeOrders = new Map();
const axios = require("axios");
const fs = require("fs");
const path = require("path");
const USERS_FILE = path.join(__dirname, "data", "users.json");
const COIN_FILE = path.join(__dirname, "data", "coinProfile.json");
const API = "https://en.awoara.com.cn/mer/store/order/smart_order/lst";
const FILE = "./lastOrder.json";
let telegramSender = null;

const DEVICE_STATUS_FILE = path.join(
    __dirname,
    "data",
    "deviceStatus.json"
);

if (!fs.existsSync(DEVICE_STATUS_FILE)) {
    fs.writeFileSync(
        DEVICE_STATUS_FILE,
        JSON.stringify({}, null, 2)
    );
}

function loadDeviceStatus() {
    try {
        return JSON.parse(
            fs.readFileSync(DEVICE_STATUS_FILE, "utf8")
        );
    } catch {
        return {};
    }
}

function saveDeviceStatus(status) {
    fs.writeFileSync(
        DEVICE_STATUS_FILE,
        JSON.stringify(status, null, 2)
    );
}

function loadUsers() {

    try {

        return JSON.parse(
            fs.readFileSync(USERS_FILE, "utf8")
        );

    } catch {

        return {};

    }

}

function loadCoinProfile(){
 try{return JSON.parse(fs.readFileSync(COIN_FILE,"utf8"));}catch{return {color:"off",music:"",relay1:false,relay2:false};}
}

function saveUsers(users) {

    fs.writeFileSync(
        USERS_FILE,
        JSON.stringify(users, null, 2)
    );

}

async function applyUserProfile(phone) {

    if (!phone) return;

    const users = loadUsers();

    const profile = users[phone];

    if (!profile) {
        console.log("Profile not found:", phone);
        return;
    }

    console.log("Applying profile:", phone);

    try {

        await axios.post(
            "https://telegramevent.onrender.com/api/control",
            {
                light: profile.color !== "off",
                color: profile.color,
                music: profile.music !== "",
                relay1: profile.relay1,
                relay2: profile.relay2,
                song: profile.music || ""
            }
        );

        console.log("Profile applied");

    } catch (e) {

        console.log(
            "Cannot apply profile:",
            e.response?.data || e.message
        );

    }

}
async function getDetail(orderSn) {
  const res = await axios.get(
    "https://en.awoara.com.cn/mer/store/order/smart_order/detail",
    {
      headers: {
        "X-Token": process.env.AWORA_TOKEN,
        Accept: "application/json",
      },
      params: { id: orderSn },
    }
  );
  return res.data.data;
}

let lastOrder = "";

if (fs.existsSync(FILE)) {
  try {
    lastOrder = JSON.parse(fs.readFileSync(FILE)).order || "";
  } catch {
    lastOrder = "";
  }
}

async function checkOrders(sendTelegram) {
    telegramSender = sendTelegram;
  try {
    const res = await axios.get(API, {
      headers: {
        "X-Token": process.env.AWORA_TOKEN,
        Accept: "application/json",
      },
      params: {
        order_sn: "",
        order_type: -1,
        keywords: "",
        membercard: "",
        status: "",
        date: "",
        page: 1,
        limit: 20,
        type: 1,
        username: "",
        order_id: "",
        activity_type: "",
        location_id: "",
        device_id: "",
        pay_type: "",
        open_type: "",
        min: 0,
        max: 0,
        machine_type: "",
        order_ch: "",
        is_api: 0,
      },
    });

const list = res.data?.data?.list || [];
console.log('Orders received:', list.length);
console.log('Last order:', lastOrder);
if (!list.length) return;



    if (!lastOrder) {
      lastOrder = list[0].order_sn;
      fs.writeFileSync(FILE, JSON.stringify({ order: lastOrder }));
      console.log("Awora initialized:", lastOrder);
      return;
    }

    const newOrders = [];
    for (const order of list) {
      if (order.order_sn === lastOrder) break;
      newOrders.push(order);
    }

    console.log('New orders:', newOrders.length);
    if (!newOrders.length) return;

    newOrders.reverse();

    for (const order of newOrders) {
if (!activeOrders.has(order.order_sn)) {
    activeOrders.set(order.order_sn, order);
}

        const phone = order.user?.phone;

if (phone) {

    const users = loadUsers();
const CURRENT_FILE = path.join(__dirname, "data", "currentProfile.json");
    if (!users[phone]) {

users[phone] = {

    phone,

    name: "",

    color: "off",

    music: "",

    relay1: false,

    relay2: false,

    vip: false,

    enabled: true,

    created: new Date().toISOString(),

    lastWash: null,

    washCount: 0,

    totalSpent: 0

};

        saveUsers(users);

        console.log("New user:", phone);

    }

let profile = users[phone];

if(order.pay_type==="coin"){
    profile = loadCoinProfile();
}

if (profile) {

    fs.writeFileSync(
        CURRENT_FILE,
        JSON.stringify(profile, null, 2)
    );

    console.log("Current profile:", phone);

}

}

      let amount = "";
      let water = 0;
      let foam = 0;
      let coat = 0;

try {
    const detail = await getDetail(order.order_sn);
        const info = detail?.body?.data?.order_info;

        if (!info) {

    console.log("Order detail not ready:", order.order_sn);

    activeOrders.set(order.order_sn, order);

    continue;

}

if (info.operation_remain_time !== 0 || info.idle_remain_time !== 0) {

    console.log("Order not finished:", order.order_sn);

    activeOrders.set(order.order_sn, order);

    continue;

}
        const programs = info.detail || [];

        const getSeconds = (name) => {
          const p = programs.find(x => x.name === name);
          return p ? p.seconds : 0;
        };

        water = getSeconds("water");
        foam = getSeconds("foam");
        coat = getSeconds("coat");

const cents =
    Number(info.card_type) === 2
        ? Number(info.amount_receivable || 0)
        : Number(info.amount_received || 0);

let finalAmount = cents / 100;

// 🪙 Только монеты делим на 2
if (order.pay_type === "coin") {
    finalAmount = finalAmount / 2;
}

amount = finalAmount.toFixed(2) + " EUR";

      } catch (e) {
        amount = "0.00 EUR";
        console.error("Detail error:", e.response?.data || e.message);
      }
        
const date = new Date(
    order.create_time.replace(" ", "T")
);

const time = new Intl.DateTimeFormat("lv-LV", {
    timeZone: "Europe/Riga",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
}).format(new Date());

let music = "OFF";
let light = "OFF";

const profile = loadUsers()[order.user?.phone];

if (profile) {

    music = profile.music || "OFF";
    light = profile.color || "OFF";

}
// ---------- Сохраняем последнюю мойку бокса ----------

const deviceName =
    order.device?.device_name || "UNKNOWN";

const deviceStatus = loadDeviceStatus();

deviceStatus[deviceName] = {
    lastWash: new Date().toISOString(),
    alerted: false
};

saveDeviceStatus(deviceStatus);
        
      const msg = `🚿 НОВЫЙ ЗАКАЗ

💳 Тип: ${order.pay_type}

📍 ${order.location?.location_name || "-"}
🔧 ${order.device?.device_name || "-"}

👤 ${order.user?.nickname || "-"}
📞 ${order.user?.phone || "-"}

💶 ${amount}

💦 Water: ${water} сек
🫧 Foam: ${foam} сек
✨ Wax: ${coat} сек
🎵 Music: ${music}
💡 Light: ${light}
🆔 ${order.order_sn}

🕒 ${time}`;

      console.log('Sending Telegram:', order.order_sn);
      try {
       
        await sendTelegram(msg);
        console.log('Telegram sent:', order.order_sn);
      } catch(e){
        console.error('Telegram ERROR:', e.response?.data || e.message);
      }

      try {
        await axios.post(
          "https://telegramevent.onrender.com/automation/event",
          {
            user: order.user?.nickname || "",
            phone: order.user?.phone || "",
            amount,
            water,
            foam,
            coat,
            payType: order.pay_type,
            device: order.device?.device_name || "",
            location: order.location?.location_name || "",
            order: order.order_sn,
            time,
          }
        );
          try {

    console.log("Waiting 30 seconds before turning OFF...");

    await new Promise(r => setTimeout(r, 30000));

const CURRENT_FILE = path.join(__dirname, "data", "currentProfile.json");

fs.writeFileSync(
    CURRENT_FILE,
    JSON.stringify({
        phone: "",
        name: "",
        color: "off",
        music: "",
        relay1: false,
        relay2: false,
        vip: false,
        plates: []
    }, null, 2)
);

console.log("Current profile cleared");

    console.log("Automation OFF");

} catch (e) {

    console.log("Cannot switch OFF:", e.message);

}
      } catch (e) {
        console.log("Automation API error:", e.message);
      }

      lastOrder = order.order_sn;
      fs.writeFileSync(FILE, JSON.stringify({ order: lastOrder }));
    }
// ---------- Проверяем незавершенные мойки ----------
for (const [orderSn, order] of activeOrders) {

    try {

        const detail = await getDetail(orderSn);

        const info = detail?.body?.data?.order_info;

        if (!info) continue;

        if (
            info.operation_remain_time !== 0 ||
            info.idle_remain_time !== 0
        ) {
            continue;
        }

        console.log("Order finished:", orderSn);

        activeOrders.delete(orderSn);

        // Здесь позже отправим Telegram

    } catch (e) {

        console.log("Active order error:", orderSn);

    }

}
  } catch (err) {
    console.error("Awora:", err.response?.data || err.message);
  }
}

// Реальное время Латвии
function latviaTime(date) {
    return new Date(date).toLocaleString("lv-LV", {
        timeZone: "Europe/Riga",
        hour12: false
    });
}


// ---------- ПРОВЕРКА ПРОСТОЯ БОКСОВ ----------

setInterval(async () => {

    const deviceStatus = loadDeviceStatus();
    const now = Date.now();

    for (const device of ["device-1", "device-2"]) {

        const status = deviceStatus[device];

        // Ещё ни одной мойки не было
        if (!status || !status.lastWash)
            continue;

        const lastWash =
            new Date(status.lastWash).getTime();

        const hours =
            (now - lastWash) / (1000 * 60 * 60);

        // Более 24 часов без мойки
        if (
            hours >= 24 &&
            !status.alerted
        ) {

            const totalMinutes =
                Math.floor(hours * 60);

            const h =
                Math.floor(totalMinutes / 60);

            const m =
                totalMinutes % 60;

            if (!telegramSender) {
                console.log("Telegram sender not ready");
                continue;
            }

            await telegramSender(
`⚠️ ALB CARWASH

🔧 ${device}
❌ Нет мойки более 24 часов

⏱ Простой:
${h} ч ${m} мин

🕒 Последняя мойка:
${latviaTime(lastWash)}`
            );

            status.alerted = true;

            saveDeviceStatus(deviceStatus);

            console.log(
                `⚠️ ${device}: больше 24 часов без мойки`
            );
        }
    }

}, 60 * 60 * 1000);

module.exports = checkOrders;
